def handler(event, context):
    """Standard handler for AgentCore Runtime."""
    return {
        "response": "Hello from Bible Companion!",
        "status": "success"
    }